/* =========================================================
   FAREED FITNESS CENTRE
   GLOBAL JAVASCRIPT
   ========================================================= */


/* =========================================================
   01. DOM READY
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    initializePageLoader();

    initializeNavbar();

    initializeMobileMenu();

    initializeScrollReveal();

    initializeSmoothLinks();

});


/* =========================================================
   02. PAGE LOADER
   ========================================================= */

function initializePageLoader() {

    const pageLoader =
        document.getElementById("pageLoader");

    if (!pageLoader) {
        return;
    }

    /*
     * Wait until the page and images have loaded.
     * The small delay makes the entrance feel cinematic.
     */

    window.addEventListener("load", () => {

        setTimeout(() => {

            pageLoader.classList.add("hidden");

        }, 700);

    });

}


/* =========================================================
   03. NAVBAR SCROLL EFFECT
   ========================================================= */

function initializeNavbar() {

    const header =
        document.getElementById("siteHeader");

    if (!header) {
        return;
    }


    function updateNavbar() {

        if (window.scrollY > 50) {

            header.classList.add("scrolled");

        } else {

            header.classList.remove("scrolled");

        }

    }


    updateNavbar();

    window.addEventListener(
        "scroll",
        updateNavbar,
        { passive: true }
    );

}


/* =========================================================
   04. MOBILE MENU
   ========================================================= */

function initializeMobileMenu() {

    const menuToggle =
        document.getElementById("menuToggle");

    const mobileMenu =
        document.getElementById("mobileMenu");

    const mobileMenuClose =
        document.getElementById("mobileMenuClose");

    if (!menuToggle || !mobileMenu) {
        return;
    }


    /* OPEN MENU */

    function openMenu() {

        mobileMenu.classList.add("active");

        document.body.classList.add("menu-open");

        menuToggle.setAttribute(
            "aria-expanded",
            "true"
        );

    }


    /* CLOSE MENU */

    function closeMenu() {

        mobileMenu.classList.remove("active");

        document.body.classList.remove("menu-open");

        menuToggle.setAttribute(
            "aria-expanded",
            "false"
        );

    }


    /* TOGGLE */

    menuToggle.addEventListener(
        "click",
        () => {

            if (
                mobileMenu.classList.contains("active")
            ) {

                closeMenu();

            } else {

                openMenu();

            }

        }
    );


    /* CLOSE BUTTON */

    if (mobileMenuClose) {

        mobileMenuClose.addEventListener(
            "click",
            closeMenu
        );

    }


    /* CLOSE AFTER NAVIGATION */

    const mobileLinks =
        mobileMenu.querySelectorAll(
            "a"
        );

    mobileLinks.forEach(link => {

        link.addEventListener(
            "click",
            closeMenu
        );

    });


    /* ESC KEY */

    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key === "Escape" &&
                mobileMenu.classList.contains("active")
            ) {

                closeMenu();

            }

        }
    );


    /* CLICK OUTSIDE */

    mobileMenu.addEventListener(
        "click",
        event => {

            if (
                event.target === mobileMenu
            ) {

                closeMenu();

            }

        }
    );


    /* RESET ON DESKTOP */

    window.addEventListener(
        "resize",
        () => {

            if (window.innerWidth > 900) {

                closeMenu();

            }

        }
    );

}


/* =========================================================
   05. SCROLL REVEAL
   ========================================================= */

function initializeScrollReveal() {

    const elements =
        document.querySelectorAll(
            ".reveal"
        );

    if (!elements.length) {
        return;
    }


    /*
     * IntersectionObserver watches elements
     * entering the viewport.
     */

    const observer =
        new IntersectionObserver(
            entries => {

                entries.forEach(entry => {

                    if (
                        entry.isIntersecting
                    ) {

                        entry.target.classList.add(
                            "visible"
                        );

                        observer.unobserve(
                            entry.target
                        );

                    }

                });

            },
            {
                threshold: 0.12
            }
        );


    elements.forEach(element => {

        observer.observe(element);

    });

}


/* =========================================================
   06. SMOOTH INTERNAL LINKS
   ========================================================= */

function initializeSmoothLinks() {

    const links =
        document.querySelectorAll(
            'a[href^="#"]'
        );

    links.forEach(link => {

        link.addEventListener(
            "click",
            event => {

                const targetId =
                    link.getAttribute("href");

                if (
                    !targetId ||
                    targetId === "#"
                ) {

                    return;

                }


                const target =
                    document.querySelector(
                        targetId
                    );

                if (!target) {
                    return;
                }


                event.preventDefault();


                target.scrollIntoView({
                    behavior: "smooth",
                    block: "start"
                });

            }
        );

    });

}


/* =========================================================
   07. CURRENT PAGE DETECTION
   ========================================================= */

function updateCurrentPageNavigation() {

    const currentPath =
        window.location.pathname;

    const navigationLinks =
        document.querySelectorAll(
            ".nav-link, .mobile-nav-link"
        );


    navigationLinks.forEach(link => {

        const linkPath =
            new URL(
                link.href,
                window.location.origin
            ).pathname;


        const isHome =
            (
                currentPath === "/" ||
                currentPath.endsWith("/index.html")
            ) &&
            (
                linkPath === "/" ||
                linkPath.endsWith("/index.html")
            );


        const isCurrentPage =
            linkPath === currentPath;


        if (
            isHome ||
            isCurrentPage
        ) {

            link.classList.add(
                "active"
            );

        } else {

            link.classList.remove(
                "active"
            );

        }

    });

}


updateCurrentPageNavigation();


/* =========================================================
   08. PAGE VISIBILITY
   ========================================================= */

document.addEventListener(
    "visibilitychange",
    () => {

        if (
            document.visibilityState === "visible"
        ) {

            document.body.classList.add(
                "page-visible"
            );

        } else {

            document.body.classList.remove(
                "page-visible"
            );

        }

    }
);


/* =========================================================
   09. PREVENT DOUBLE SUBMISSION
   ========================================================= */

function preventDoubleSubmission(
    form,
    button
) {

    if (!form || !button) {
        return;
    }


    form.addEventListener(
        "submit",
        () => {

            button.disabled = true;

            setTimeout(() => {

                button.disabled = false;

            }, 3000);

        }
    );

}


/* =========================================================
   10. GLOBAL UTILITY
   ========================================================= */

function getElement(selector) {

    return document.querySelector(
        selector
    );

}


function getElements(selector) {

    return document.querySelectorAll(
        selector
    );

}


/* =========================================================
   END OF GLOBAL JAVASCRIPT
   ========================================================= */