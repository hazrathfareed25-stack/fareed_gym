/* =========================================================
   FAREED FITNESS CENTRE
   ABOUT PAGE JAVASCRIPT
   ========================================================= */


/* =========================================================
   01. DOM READY
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    initializeAboutParallax();

    initializeFacilityCards();

});


/* =========================================================
   02. ABOUT HERO PARALLAX
   ========================================================= */

function initializeAboutParallax() {

    const hero =
        document.querySelector(".about-hero");

    const image =
        document.querySelector(".about-hero-image");


    if (!hero || !image) {
        return;
    }


    const reducedMotion =
        window.matchMedia(
            "(prefers-reduced-motion: reduce)"
        ).matches;


    const touchDevice =
        window.matchMedia(
            "(hover: none)"
        ).matches;


    if (reducedMotion || touchDevice) {
        return;
    }


    let ticking = false;


    function updateParallax() {

        const scroll =
            window.scrollY;

        const heroHeight =
            hero.offsetHeight;


        if (scroll <= heroHeight) {

            const movement =
                scroll * 0.15;

            image.style.transform =
                `scale(1.08) translateY(${movement}px)`;

        }


        ticking = false;

    }


    window.addEventListener(
        "scroll",
        () => {

            if (!ticking) {

                requestAnimationFrame(
                    updateParallax
                );

                ticking = true;

            }

        },
        {
            passive: true
        }
    );

}


/* =========================================================
   03. FACILITY CARD INTERACTION
   ========================================================= */

function initializeFacilityCards() {

    const cards =
        document.querySelectorAll(
            ".facility-card"
        );


    if (!cards.length) {
        return;
    }


    const touchDevice =
        window.matchMedia(
            "(hover: none)"
        ).matches;


    const reducedMotion =
        window.matchMedia(
            "(prefers-reduced-motion: reduce)"
        ).matches;


    if (
        touchDevice ||
        reducedMotion
    ) {
        return;
    }


    cards.forEach(card => {

        card.addEventListener(
            "mousemove",
            event => {

                const rect =
                    card.getBoundingClientRect();


                const x =
                    event.clientX -
                    rect.left;


                const y =
                    event.clientY -
                    rect.top;


                const centerX =
                    rect.width / 2;


                const centerY =
                    rect.height / 2;


                const rotateX =
                    ((y - centerY) /
                        centerY) *
                    -1.5;


                const rotateY =
                    ((x - centerX) /
                        centerX) *
                    1.5;


                card.style.transform =
                    `perspective(1000px)
                     rotateX(${rotateX}deg)
                     rotateY(${rotateY}deg)
                     translateY(-5px)`;

            }
        );


        card.addEventListener(
            "mouseleave",
            () => {

                card.style.transform = "";

            }
        );

    });

}


/* =========================================================
   04. FAREED IMAGE HOVER
   ========================================================= */

function initializeFareedImageEffect() {

    const section =
        document.querySelector(
            ".fareed-feature"
        );

    const image =
        document.querySelector(
            ".fareed-feature-image img"
        );


    if (!section || !image) {
        return;
    }


    const touchDevice =
        window.matchMedia(
            "(hover: none)"
        ).matches;


    const reducedMotion =
        window.matchMedia(
            "(prefers-reduced-motion: reduce)"
        ).matches;


    if (
        touchDevice ||
        reducedMotion
    ) {
        return;
    }


    section.addEventListener(
        "mousemove",
        event => {

            const rect =
                section.getBoundingClientRect();


            const x =
                (
                    event.clientX -
                    rect.left
                ) /
                rect.width;


            const y =
                (
                    event.clientY -
                    rect.top
                ) /
                rect.height;


            const moveX =
                (x - 0.5) * 10;


            const moveY =
                (y - 0.5) * 6;


            image.style.transform =
                `scale(1.06)
                 translate(${moveX}px, ${moveY}px)`;

        }
    );


    section.addEventListener(
        "mouseleave",
        () => {

            image.style.transform =
                "scale(1.05)";

        }
    );

}


/* =========================================================
   05. INITIALIZE FAREED IMAGE EFFECT
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeFareedImageEffect();

    }
);


/* =========================================================
   06. FACILITY IMAGE LAZY LOADING
   ========================================================= */

function initializeFacilityImages() {

    const images =
        document.querySelectorAll(
            ".facility-image img"
        );


    if (!images.length) {
        return;
    }


    images.forEach(image => {

        image.addEventListener(
            "load",
            () => {

                image.classList.add(
                    "loaded"
                );

            }
        );

    });

}


/* =========================================================
   07. INITIALIZE IMAGE LOADING
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeFacilityImages();

    }
);


/* =========================================================
   END OF ABOUT JAVASCRIPT
   ========================================================= */