/* =========================================================
   FAREED FITNESS CENTRE
   CONTACT PAGE JAVASCRIPT
   ========================================================= */


/* =========================================================
   01. DOM READY
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    initializeContactForm();

    initializeContactSuccess();

    initializeContactMapEffect();

});


/* =========================================================
   02. CONTACT FORM
   ========================================================= */

function initializeContactForm() {

    const form =
        document.getElementById("contactForm");

    if (!form) {
        return;
    }


    form.addEventListener("submit", event => {

        event.preventDefault();

        clearContactErrors();


        const valid =
            validateContactForm(form);


        if (!valid) {
            return;
        }


        const submitButton =
            form.querySelector(".contact-submit");


        if (submitButton) {

            submitButton.disabled = true;

            submitButton.innerHTML = `
                SENDING
                <span>...</span>
            `;

        }


        /*
         * Front-end demonstration only.
         * No backend/database is connected.
         */

        setTimeout(() => {

            showContactSuccess();

            form.reset();


            if (submitButton) {

                submitButton.disabled = false;

                submitButton.innerHTML = `
                    SEND MESSAGE
                    <span>→</span>
                `;

            }

        }, 900);

    });

}


/* =========================================================
   03. FORM VALIDATION
   ========================================================= */

function validateContactForm(form) {

    let valid = true;


    const name =
        document.getElementById("contactName");

    const email =
        document.getElementById("contactEmail");

    const phone =
        document.getElementById("contactPhone");

    const subject =
        document.getElementById("contactSubject");

    const message =
        document.getElementById("contactMessage");


    /* NAME */

    if (
        name &&
        name.value.trim().length < 2
    ) {

        showContactError(
            "contactNameError",
            "Please enter your name."
        );

        valid = false;

    }


    /* EMAIL */

    if (email) {

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


        if (
            !emailPattern.test(
                email.value.trim()
            )
        ) {

            showContactError(
                "contactEmailError",
                "Please enter a valid email address."
            );

            valid = false;

        }

    }


    /* PHONE */

    if (phone) {

        const phoneDigits =
            phone.value.replace(
                /\D/g,
                ""
            );


        if (
            phoneDigits.length < 10
        ) {

            showContactError(
                "contactPhoneError",
                "Please enter a valid phone number."
            );

            valid = false;

        }

    }


    /* SUBJECT */

    if (
        subject &&
        !subject.value
    ) {

        showContactError(
            "contactSubjectError",
            "Please select a subject."
        );

        valid = false;

    }


    /* MESSAGE */

    if (
        message &&
        message.value.trim().length < 10
    ) {

        showContactError(
            "contactMessageError",
            "Please enter at least 10 characters."
        );

        valid = false;

    }


    return valid;

}


/* =========================================================
   04. SHOW ERROR
   ========================================================= */

function showContactError(
    elementId,
    message
) {

    const error =
        document.getElementById(
            elementId
        );


    if (!error) {
        return;
    }


    error.textContent =
        message;

}


/* =========================================================
   05. CLEAR ERRORS
   ========================================================= */

function clearContactErrors() {

    const errors =
        document.querySelectorAll(
            ".contact-form .form-error"
        );


    errors.forEach(error => {

        error.textContent = "";

    });

}


/* =========================================================
   06. SUCCESS POPUP
   ========================================================= */

function showContactSuccess() {

    const success =
        document.getElementById(
            "contactSuccess"
        );


    if (!success) {
        return;
    }


    success.classList.add("active");

    success.setAttribute(
        "aria-hidden",
        "false"
    );

    document.body.classList.add(
        "menu-open"
    );

}


/* =========================================================
   07. CLOSE SUCCESS POPUP
   ========================================================= */

function initializeContactSuccess() {

    const success =
        document.getElementById(
            "contactSuccess"
        );

    const closeButton =
        document.getElementById(
            "contactSuccessClose"
        );


    if (
        !success ||
        !closeButton
    ) {
        return;
    }


    function closeSuccess() {

        success.classList.remove(
            "active"
        );

        success.setAttribute(
            "aria-hidden",
            "true"
        );

        document.body.classList.remove(
            "menu-open"
        );

    }


    closeButton.addEventListener(
        "click",
        closeSuccess
    );


    success.addEventListener(
        "click",
        event => {

            if (
                event.target === success
            ) {

                closeSuccess();

            }

        }
    );


    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key === "Escape" &&
                success.classList.contains(
                    "active"
                )
            ) {

                closeSuccess();

            }

        }
    );

}


/* =========================================================
   08. LIVE INPUT VALIDATION
   ========================================================= */

function initializeContactInputs() {

    const inputs =
        document.querySelectorAll(
            "#contactForm input, #contactForm textarea, #contactForm select"
        );


    inputs.forEach(input => {

        input.addEventListener(
            "input",
            () => {

                clearSingleContactError(
                    input.id
                );

            }
        );


        input.addEventListener(
            "change",
            () => {

                clearSingleContactError(
                    input.id
                );

            }
        );

    });

}


/* =========================================================
   09. CLEAR SINGLE ERROR
   ========================================================= */

function clearSingleContactError(
    inputId
) {

    const error =
        document.getElementById(
            `${inputId}Error`
        );


    if (error) {

        error.textContent = "";

    }

}


/* =========================================================
   10. INITIALIZE INPUTS
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeContactInputs();

    }
);


/* =========================================================
   11. MAP INTERACTION
   ========================================================= */

function initializeContactMapEffect() {

    const map =
        document.querySelector(
            ".location-map"
        );

    if (!map) {
        return;
    }


    const touchDevice =
        window.matchMedia(
            "(hover: none)"
        ).matches;


    const reducedMotion =
        window.matchMedia(
            "(prefers-reduced-motion: reduce)"
        ).matches;


    if (
        touchDevice ||
        reducedMotion
    ) {
        return;
    }


    const marker =
        map.querySelector(
            ".map-marker"
        );


    if (!marker) {
        return;
    }


    map.addEventListener(
        "mousemove",
        event => {

            const rect =
                map.getBoundingClientRect();


            const x =
                (
                    event.clientX -
                    rect.left
                ) /
                rect.width;


            const y =
                (
                    event.clientY -
                    rect.top
                ) /
                rect.height;


            const moveX =
                (x - 0.5) * 12;


            const moveY =
                (y - 0.5) * 8;


            marker.style.transform =
                `
                translate(
                    calc(-50% + ${moveX}px),
                    calc(-50% + ${moveY}px)
                )
                `;

        }
    );


    map.addEventListener(
        "mouseleave",
        () => {

            marker.style.transform =
                "translate(-50%, -50%)";

        }
    );

}


/* =========================================================
   12. PHONE NUMBER CLEANUP
   ========================================================= */

function initializePhoneInput() {

    const phone =
        document.getElementById(
            "contactPhone"
        );


    if (!phone) {
        return;
    }


    phone.addEventListener(
        "input",
        () => {

            /*
             * Allow numbers, spaces, +, -, and parentheses.
             */

            phone.value =
                phone.value.replace(
                    /[^0-9+\-\s()]/g,
                    ""
                );

        }
    );

}


/* =========================================================
   13. INITIALIZE PHONE INPUT
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializePhoneInput();

    }
);


/* =========================================================
   END OF CONTACT JAVASCRIPT
   ========================================================= */