/* =========================================================
   FAREED FITNESS CENTRE
   MEMBERSHIP PAGE JAVASCRIPT
   ========================================================= */


/* =========================================================
   01. DOM READY
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    initializeMembershipSelection();

    initializeRegistrationForm();

    initializeSuccessScreen();

});


/* =========================================================
   02. MEMBERSHIP PLAN SELECTION
   ========================================================= */

function initializeMembershipSelection() {

    const planButtons =
        document.querySelectorAll(
            ".plan-button"
        );

    const selectedPlan =
        document.getElementById(
            "selectedPlan"
        );


    if (
        !planButtons.length ||
        !selectedPlan
    ) {
        return;
    }


    planButtons.forEach(button => {

        button.addEventListener(
            "click",
            () => {

                const plan =
                    button.dataset.plan ||
                    button.closest(
                        ".membership-card"
                    )?.dataset.plan ||
                    "Membership";


                selectedPlan.textContent =
                    plan;


                /*
                 * Store the selected plan
                 * so it survives page interaction.
                 */

                try {

                    localStorage.setItem(
                        "fareedSelectedPlan",
                        plan
                    );

                } catch (error) {

                    console.warn(
                        "Local storage unavailable."
                    );

                }


                /*
                 * Scroll to registration form.
                 */

                const registration =
                    document.querySelector(
                        ".registration-section"
                    );


                if (registration) {

                    registration.scrollIntoView({
                        behavior: "smooth",
                        block: "start"
                    });

                }

            }
        );

    });


    /*
     * Restore previously selected plan.
     */

    try {

        const savedPlan =
            localStorage.getItem(
                "fareedSelectedPlan"
            );


        if (savedPlan) {

            selectedPlan.textContent =
                savedPlan;

        }

    } catch (error) {

        console.warn(
            "Could not restore membership selection."
        );

    }

}


/* =========================================================
   03. REGISTRATION FORM
   ========================================================= */

function initializeRegistrationForm() {

    const form =
        document.getElementById(
            "registrationForm"
        );


    if (!form) {
        return;
    }


    form.addEventListener(
        "submit",
        event => {

            event.preventDefault();


            clearRegistrationErrors();


            const isValid =
                validateRegistrationForm(
                    form
                );


            if (!isValid) {
                return;
            }


            const submitButton =
                form.querySelector(
                    ".registration-submit"
                );


            if (submitButton) {

                submitButton.disabled = true;

                submitButton.innerHTML =
                    `
                    PROCESSING
                    <span>...</span>
                    `;

            }


            /*
             * This is a front-end-only project.
             *
             * We simulate successful registration
             * instead of sending data to a server.
             */

            setTimeout(() => {

                showRegistrationSuccess();

                form.reset();

                if (submitButton) {

                    submitButton.disabled = false;

                    submitButton.innerHTML =
                        `
                        COMPLETE REGISTRATION
                        <span>→</span>
                        `;

                }

            }, 900);

        }
    );

}


/* =========================================================
   04. FORM VALIDATION
   ========================================================= */

function validateRegistrationForm(form) {

    let valid = true;


    const name =
        document.getElementById(
            "registrationName"
        );

    const email =
        document.getElementById(
            "registrationEmail"
        );

    const phone =
        document.getElementById(
            "registrationPhone"
        );

    const plan =
        document.getElementById(
            "registrationPlan"
        );


    /* NAME */

    if (
        name &&
        name.value.trim().length < 2
    ) {

        showRegistrationError(
            "registrationNameError",
            "Please enter your full name."
        );

        valid = false;

    }


    /* EMAIL */

    if (email) {

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;


        if (
            !emailPattern.test(
                email.value.trim()
            )
        ) {

            showRegistrationError(
                "registrationEmailError",
                "Please enter a valid email address."
            );

            valid = false;

        }

    }


    /* PHONE */

    if (phone) {

        const phoneDigits =
            phone.value.replace(
                /\D/g,
                ""
            );


        if (
            phoneDigits.length < 10
        ) {

            showRegistrationError(
                "registrationPhoneError",
                "Please enter a valid phone number."
            );

            valid = false;

        }

    }


    /* PLAN */

    if (
        plan &&
        !plan.value
    ) {

        showRegistrationError(
            "registrationPlanError",
            "Please select a membership plan."
        );

        valid = false;

    }


    return valid;

}


/* =========================================================
   05. ERROR DISPLAY
   ========================================================= */

function showRegistrationError(
    elementId,
    message
) {

    const error =
        document.getElementById(
            elementId
        );


    if (!error) {
        return;
    }


    error.textContent =
        message;

}


/* =========================================================
   06. CLEAR ERRORS
   ========================================================= */

function clearRegistrationErrors() {

    const errors =
        document.querySelectorAll(
            ".form-error"
        );


    errors.forEach(error => {

        error.textContent = "";

    });

}


/* =========================================================
   07. SUCCESS SCREEN
   ========================================================= */

function showRegistrationSuccess() {

    const successScreen =
        document.getElementById(
            "successScreen"
        );


    if (!successScreen) {
        return;
    }


    successScreen.classList.add(
        "active"
    );


    document.body.classList.add(
        "menu-open"
    );


    successScreen.setAttribute(
        "aria-hidden",
        "false"
    );

}


/* =========================================================
   08. CLOSE SUCCESS SCREEN
   ========================================================= */

function initializeSuccessScreen() {

    const successScreen =
        document.getElementById(
            "successScreen"
        );

    const closeButton =
        document.getElementById(
            "successClose"
        );


    if (
        !successScreen ||
        !closeButton
    ) {
        return;
    }


    function closeSuccess() {

        successScreen.classList.remove(
            "active"
        );


        document.body.classList.remove(
            "menu-open"
        );


        successScreen.setAttribute(
            "aria-hidden",
            "true"
        );

    }


    closeButton.addEventListener(
        "click",
        closeSuccess
    );


    successScreen.addEventListener(
        "click",
        event => {

            if (
                event.target ===
                successScreen
            ) {

                closeSuccess();

            }

        }
    );


    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key === "Escape" &&
                successScreen.classList.contains(
                    "active"
                )
            ) {

                closeSuccess();

            }

        }
    );

}


/* =========================================================
   09. PLAN CARD HIGHLIGHT
   ========================================================= */

function initializePlanHighlight() {

    const cards =
        document.querySelectorAll(
            ".membership-card"
        );


    cards.forEach(card => {

        const button =
            card.querySelector(
                ".plan-button"
            );


        if (!button) {
            return;
        }


        button.addEventListener(
            "click",
            () => {

                cards.forEach(
                    otherCard => {

                        otherCard.classList.remove(
                            "selected"
                        );

                    }
                );


                card.classList.add(
                    "selected"
                );

            }
        );

    });

}


/* =========================================================
   10. INITIALIZE PLAN HIGHLIGHT
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializePlanHighlight();

    }
);


/* =========================================================
   11. INPUT FEEDBACK
   ========================================================= */

function initializeInputFeedback() {

    const inputs =
        document.querySelectorAll(
            ".registration-form input, .registration-form select"
        );


    inputs.forEach(input => {

        input.addEventListener(
            "input",
            () => {

                const errorId =
                    `${input.id}Error`;


                const error =
                    document.getElementById(
                        errorId
                    );


                if (error) {

                    error.textContent =
                        "";

                }

            }
        );

    });

}


/* =========================================================
   12. INITIALIZE INPUT FEEDBACK
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeInputFeedback();

    }
);


/* =========================================================
   END OF MEMBERSHIP JAVASCRIPT
   ========================================================= */