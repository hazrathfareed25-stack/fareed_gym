/* =========================================================
   FAREED FITNESS CENTRE
   HOME PAGE JAVASCRIPT
   ========================================================= */


/* =========================================================
   01. DOM READY
   ========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    initializeHomeCounters();

    initializeHomeParallax();

    initializeHeroMouseEffect();

});


/* =========================================================
   02. STATISTICS COUNTER
   ========================================================= */

function initializeHomeCounters() {

    const counters =
        document.querySelectorAll(
            ".stat-number[data-target]"
        );

    if (!counters.length) {
        return;
    }


    let hasStarted = false;


    function animateCounters() {

        if (hasStarted) {
            return;
        }

        hasStarted = true;


        counters.forEach(counter => {

            const target =
                Number(
                    counter.dataset.target
                );

            const duration = 1800;

            const startTime =
                performance.now();


            function updateCounter(currentTime) {

                const elapsed =
                    currentTime - startTime;

                const progress =
                    Math.min(
                        elapsed / duration,
                        1
                    );


                /*
                 * Ease-out animation:
                 * starts quickly and slows near the target.
                 */

                const easedProgress =
                    1 -
                    Math.pow(
                        1 - progress,
                        3
                    );


                const currentValue =
                    Math.floor(
                        easedProgress * target
                    );


                counter.textContent =
                    currentValue.toLocaleString();


                if (progress < 1) {

                    requestAnimationFrame(
                        updateCounter
                    );

                } else {

                    counter.textContent =
                        target.toLocaleString();

                }

            }


            requestAnimationFrame(
                updateCounter
            );

        });

    }


    /* Start counters only when visible */

    const statsSection =
        document.querySelector(
            ".statistics"
        );

    if (!statsSection) {
        return;
    }


    const observer =
        new IntersectionObserver(
            entries => {

                entries.forEach(entry => {

                    if (
                        entry.isIntersecting
                    ) {

                        animateCounters();

                        observer.disconnect();

                    }

                });

            },
            {
                threshold: 0.3
            }
        );


    observer.observe(
        statsSection
    );

}


/* =========================================================
   03. HERO PARALLAX
   ========================================================= */

function initializeHomeParallax() {

    const hero =
        document.querySelector(
            ".hero"
        );

    const heroImage =
        document.querySelector(
            ".hero-image"
        );


    if (!hero || !heroImage) {
        return;
    }


    /*
     * Disable parallax for users who prefer
     * reduced motion.
     */

    const reducedMotion =
        window.matchMedia(
            "(prefers-reduced-motion: reduce)"
        ).matches;

    if (reducedMotion) {
        return;
    }


    let ticking = false;


    function updateParallax() {

        const scrollPosition =
            window.scrollY;

        const heroHeight =
            hero.offsetHeight;


        /*
         * Only apply the effect while the
         * hero is visible.
         */

        if (
            scrollPosition <= heroHeight
        ) {

            const movement =
                scrollPosition * 0.18;

            heroImage.style.transform =
                `scale(1.08) translateY(${movement}px)`;

        }


        ticking = false;

    }


    window.addEventListener(
        "scroll",
        () => {

            if (!ticking) {

                requestAnimationFrame(
                    updateParallax
                );

                ticking = true;

            }

        },
        {
            passive: true
        }
    );

}


/* =========================================================
   04. HERO MOUSE MOVEMENT
   ========================================================= */

function initializeHeroMouseEffect() {

    const hero =
        document.querySelector(
            ".hero"
        );

    const heroImage =
        document.querySelector(
            ".hero-image"
        );

    const heroContent =
        document.querySelector(
            ".hero-content"
        );


    if (
        !hero ||
        !heroImage ||
        !heroContent
    ) {
        return;
    }


    /*
     * Check whether the device is likely
     * touch-based.
     */

    const isTouchDevice =
        window.matchMedia(
            "(hover: none)"
        ).matches;


    const reducedMotion =
        window.matchMedia(
            "(prefers-reduced-motion: reduce)"
        ).matches;


    if (
        isTouchDevice ||
        reducedMotion
    ) {
        return;
    }


    hero.addEventListener(
        "mousemove",
        event => {

            const rect =
                hero.getBoundingClientRect();


            const x =
                (
                    event.clientX -
                    rect.left
                ) /
                rect.width;


            const y =
                (
                    event.clientY -
                    rect.top
                ) /
                rect.height;


            /*
             * Convert mouse position into
             * subtle movement values.
             */

            const moveX =
                (x - 0.5) * 12;

            const moveY =
                (y - 0.5) * 8;


            heroImage.style.transform =
                `scale(1.08) translate(${moveX}px, ${moveY}px)`;


            heroContent.style.transform =
                `translate(${moveX * 0.12}px, ${moveY * 0.12}px)`;

        }
    );


    hero.addEventListener(
        "mouseleave",
        () => {

            heroImage.style.transform =
                "scale(1.08)";

            heroContent.style.transform =
                "translate(0, 0)";

        }
    );

}


/* =========================================================
   05. DESTINATION CARD TILT
   ========================================================= */

function initializeDestinationTilt() {

    const cards =
        document.querySelectorAll(
            ".destination-card"
        );


    if (!cards.length) {
        return;
    }


    const isTouchDevice =
        window.matchMedia(
            "(hover: none)"
        ).matches;


    if (isTouchDevice) {
        return;
    }


    cards.forEach(card => {

        card.addEventListener(
            "mousemove",
            event => {

                const rect =
                    card.getBoundingClientRect();


                const x =
                    event.clientX -
                    rect.left;


                const y =
                    event.clientY -
                    rect.top;


                const centerX =
                    rect.width / 2;


                const centerY =
                    rect.height / 2;


                const rotateX =
                    ((y - centerY) /
                        centerY) *
                    -2;


                const rotateY =
                    ((x - centerX) /
                        centerX) *
                    2;


                card.style.transform =
                    `perspective(900px)
                     rotateX(${rotateX}deg)
                     rotateY(${rotateY}deg)
                     translateY(-5px)`;

            }
        );


        card.addEventListener(
            "mouseleave",
            () => {

                card.style.transform =
                    "";

            }
        );

    });

}


/* =========================================================
   06. INITIALIZE DESTINATION TILT
   ========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        initializeDestinationTilt();

    }
);


/* =========================================================
   END OF HOME JAVASCRIPT
   ========================================================= */